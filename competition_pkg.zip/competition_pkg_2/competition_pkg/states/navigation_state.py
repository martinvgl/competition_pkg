#!/usr/bin/env python3

import rclpy

from geometry_msgs.msg import Twist

from yasmin import State
from yasmin import Blackboard


class NavigationState(State):

    def __init__(self, node):

        super().__init__(outcomes=["done"])

        self.node = node

        self.vel_pub = self.node.create_publisher(
            Twist,
            "/cmd_vel",
            10,
        )

    def execute(self, blackboard: Blackboard):

        cmd = Twist()

        cmd.linear.x = 0.08

        self.vel_pub.publish(cmd)

        self.node.get_logger().info(
            "Navigating evacuation path"
        )

        return "done"