#!/usr/bin/env python3

from yasmin import State
from yasmin import Blackboard


class DangerState(State):

    def __init__(self, node):

        super().__init__(outcomes=["recover"])

        self.node = node

    def execute(self, blackboard: Blackboard):

        self.node.get_logger().warn(
            "DANGER DETECTED"
        )

        return "recover"