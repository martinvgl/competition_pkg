#!/usr/bin/env python3

import rclpy

from std_msgs.msg import String

from yasmin import State
from yasmin import Blackboard


class FollowSafeState(State):

    def __init__(self, node):

        super().__init__(outcomes=["danger", "safe", "caution"])

        self.node = node

        self.current_status = "searching"

        self.status_sub = self.node.create_subscription(
            String,
            "/evacuation_status",
            self.status_callback,
            10,
        )

    def status_callback(self, msg):

        self.current_status = msg.data

    def execute(self, blackboard: Blackboard):

        while rclpy.ok():

            rclpy.spin_once(self.node)

            self.node.get_logger().info(
                f"Current Status: {self.current_status}"
            )

            if self.current_status == "danger":
                return "danger"

            elif self.current_status == "caution":
                return "caution"

            elif self.current_status == "safe":
                return "safe"