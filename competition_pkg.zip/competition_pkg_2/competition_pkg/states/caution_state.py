#!/usr/bin/env python3

from yasmin import State
from yasmin import Blackboard


class CautionState(State):

    def __init__(self, node):

        super().__init__(outcomes=["continue"])

        self.node = node

    def execute(self, blackboard: Blackboard):

        self.node.get_logger().info(
            "CAUTION AREA"
        )

        return "continue"