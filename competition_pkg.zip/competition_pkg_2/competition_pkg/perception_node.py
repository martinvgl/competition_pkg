#!/usr/bin/env python3

import cv2
import numpy as np

import rclpy

from rclpy.node import Node

from sensor_msgs.msg import Image
from std_msgs.msg import String

from cv_bridge import CvBridge


class PerceptionNode(Node):

    def __init__(self):

        super().__init__("perception_node")

        self.bridge = CvBridge()

        self.image_sub = self.create_subscription(
            Image,
            "/image_raw",
            self.image_callback,
            10,
        )

        self.status_pub = self.create_publisher(
            String,
            "/evacuation_status",
            10,
        )

        self.people_pub = self.create_publisher(
            String,
            "/people_count",
            10,
        )

    def image_callback(self, msg):

        frame = self.bridge.imgmsg_to_cv2(msg, "bgr8")

        hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)

        # RED
        lower_red = np.array([0,150,150])
        upper_red = np.array([10,255,255])

        # GREEN
        lower_green = np.array([40,100,100])
        upper_green = np.array([90,255,255])

        # YELLOW
        lower_yellow = np.array([20,100,100])
        upper_yellow = np.array([35,255,255])

        red_mask = cv2.inRange(hsv, lower_red, upper_red)
        green_mask = cv2.inRange(hsv, lower_green, upper_green)
        yellow_mask = cv2.inRange(hsv, lower_yellow, upper_yellow)

        red_pixels = np.sum(red_mask > 0)
        green_pixels = np.sum(green_mask > 0)
        yellow_pixels = np.sum(yellow_mask > 0)

        status_msg = String()

        if red_pixels > 5000:

            status_msg.data = "danger"

        elif yellow_pixels > 5000:

            status_msg.data = "caution"

        elif green_pixels > 5000:

            status_msg.data = "safe"

        else:

            status_msg.data = "searching"

        self.status_pub.publish(status_msg)

        # Placeholder people count
        people_msg = String()
        people_msg.data = "People detected: 0"

        self.people_pub.publish(people_msg)

        self.get_logger().info(status_msg.data)


def main(args=None):

    rclpy.init(args=args)

    node = PerceptionNode()

    rclpy.spin(node)

    node.destroy_node()

    rclpy.shutdown()


if __name__ == "__main__":
    main()