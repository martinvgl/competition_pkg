#!/usr/bin/env python3

import rclpy

from rclpy.node import Node

from yasmin import StateMachine
from yasmin_viewer import YasminViewerPub

from .states import follow_safe_state
from .states import danger_state
from .states import caution_state
from .states import navigation_state


class StateMachineNode(Node):

    def __init__(self):

        super().__init__("sm_evacuation_node")

        self.get_logger().info(
            "Emergency Evacuation State Machine Started"
        )

        # Create State Machine
        sm = StateMachine(outcomes=["EXIT"])

        # FOLLOW SAFE STATE
        sm.add_state(
            name="FOLLOW_SAFE",
            state=follow_safe_state.FollowSafeState(self),
            transitions={
                "danger": "DANGER",
                "caution": "CAUTION",
                "safe": "NAVIGATION",
            },
        )

        # DANGER STATE
        sm.add_state(
            name="DANGER",
            state=danger_state.DangerState(self),
            transitions={
                "recover": "FOLLOW_SAFE",
            },
        )

        # CAUTION STATE
        sm.add_state(
            name="CAUTION",
            state=caution_state.CautionState(self),
            transitions={
                "continue": "FOLLOW_SAFE",
            },
        )

        # NAVIGATION STATE
        sm.add_state(
            name="NAVIGATION",
            state=navigation_state.NavigationState(self),
            transitions={
                "done": "FOLLOW_SAFE",
            },
        )

        # Publish FSM to Yasmin Viewer
        YasminViewerPub(
            fsm_name="EMERGENCY_EVACUATION",
            fsm=sm,
        )

        # Execute State Machine
        outcome = sm()

        self.get_logger().info(
            f"State Machine Finished: {outcome}"
        )


def main(args=None):

    rclpy.init(args=args)

    node = StateMachineNode()

    node.destroy_node()

    rclpy.shutdown()


if __name__ == "__main__":
    main()