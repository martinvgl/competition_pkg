from setuptools import find_packages, setup
import os
from glob import glob

package_name = "competition_pkg"

setup(
    name=package_name,
    version="0.0.0",
    packages=find_packages(exclude=["test"]),
    data_files=[
        ("share/ament_index/resource_index/packages", ["resource/" + package_name]),
        ("share/" + package_name, ["package.xml"]),
    ],
    install_requires=["setuptools"],
    zip_safe=True,
    maintainer="Tomoaki Fujino",
    maintainer_email="fujino0728@gmail.com",
    description="competition: State Machine (YASMIN) — PATROL/MAPPING/FOLLOW/NAVIGATION",
    license="Apache-2.0",
    tests_require=["pytest"],
    entry_points={
        "console_scripts": [
            "sm = competition_pkg.sm:main",
            "fakerobot = competition_pkg.fakerobot:main",
            "obstacle_mapper = competition_pkg.obstacle_mapper_node:main",
        ],
    },
)
