#!/usr/bin/env python3
# -*- coding: UTF-8 -*-

"""
File: state_main/patrol.py

PatrolState — autonomous waypoint navigation.
Uses Nav2 NavigateToPose action.

Outcomes:
  "patrol"       → waypoint reached, advance to next waypoint
  "detected"     → new obstacle signaled on /new_obstacle → switch to MAPPING
  "person_found" → person detected by FollowState sensors (reserved for
                   future direct integration; currently not triggered here)

Note: person detection is handled inside FollowState (camera).
      The "person_found" transition is wired in the SM for extensibility
      but PatrolState itself only emits "patrol" and "detected".
"""

import math

import rclpy
from rclpy.node import Node
from rclpy.action import ActionClient

from geometry_msgs.msg import PoseStamped
from action_msgs.msg import GoalStatus
from nav2_msgs.action import NavigateToPose
from std_msgs.msg import String

import tf_transformations

from yasmin import State
from yasmin import Blackboard


# ── Patrol waypoints ─────────────────────────────────────────────────────────
# Adapt these coordinates to your actual environment (metres, frame "map").
WAYPOINTS = [
    {"x": 0.0, "y": 0.0,  "yaw": 0.0},
    {"x": 2.0, "y": 0.0,  "yaw": 1.5708},
    {"x": 2.0, "y": 2.0,  "yaw": 3.1416},
    {"x": 0.0, "y": 2.0,  "yaw": -1.5708},
]


class PatrolState(State):
    """Navigates autonomously along a list of waypoints.

    Listens to /new_obstacle published by obstacle_mapper_node.
    Cancels the current Nav2 goal and returns "detected" when an alert
    arrives so that the SM can transition to MappingState.
    """

    def __init__(self, node: Node):
        super().__init__(outcomes=["patrol", "detected", "person_found"])

        self.node = node
        self.waypoint_index = 0
        self.new_obstacle_detected = False

        self._goal_handle = None
        self._result_future = None
        self._status = None

        self.nav_to_pose_client = ActionClient(
            node=self.node,
            action_type=NavigateToPose,
            action_name="/navigate_to_pose",
        )

        self.node.create_subscription(
            msg_type=String,
            topic="/new_obstacle",
            callback=self._obstacle_cb,
            qos_profile=10,
        )

    # ── Callbacks ─────────────────────────────────────────────────────────────

    def _obstacle_cb(self, msg: String):
        """Called when obstacle_mapper_node detects a new obstacle."""
        self.node.get_logger().warn(
            f"[PATROL] New obstacle: {msg.data}"
        )
        self.new_obstacle_detected = True

    # ── Nav2 helpers ──────────────────────────────────────────────────────────

    def _go_to_pose(self, x: float, y: float, yaw: float) -> bool:
        """Send a NavigateToPose goal and return True if accepted."""
        while not self.nav_to_pose_client.wait_for_server(timeout_sec=1.0):
            self.node.get_logger().info(
                "[PATROL] Waiting for NavigateToPose action server..."
            )

        pose = PoseStamped()
        pose.header.stamp = self.node.get_clock().now().to_msg()
        pose.header.frame_id = "map"
        pose.pose.position.x = x
        pose.pose.position.y = y
        pose.pose.position.z = 0.0

        quat = tf_transformations.quaternion_from_euler(0, 0, yaw)  # [x, y, z, w]
        pose.pose.orientation.x = quat[1]
        pose.pose.orientation.y = quat[2]
        pose.pose.orientation.z = quat[3]
        pose.pose.orientation.w = quat[0]

        goal_msg = NavigateToPose.Goal()
        goal_msg.pose = pose

        self.node.get_logger().info(
            f"[PATROL] Navigating to waypoint {self.waypoint_index}: "
            f"(x={x:.2f}, y={y:.2f}, yaw={math.degrees(yaw):.0f}°)"
        )

        send_goal_future = self.nav_to_pose_client.send_goal_async(goal_msg)
        rclpy.spin_until_future_complete(self.node, send_goal_future)

        self._goal_handle = send_goal_future.result()
        if not self._goal_handle.accepted:
            self.node.get_logger().error("[PATROL] Goal rejected!")
            return False

        self.node.get_logger().info("[PATROL] Goal accepted.")
        self._result_future = self._goal_handle.get_result_async()
        return True

    def _is_nav_complete(self) -> bool:
        """Return True when the Nav2 action has finished (success or failure)."""
        if not self._result_future:
            return True
        rclpy.spin_until_future_complete(
            self.node, self._result_future, timeout_sec=0.1
        )
        if self._result_future.result():
            self._status = self._result_future.result().status
            return True
        return False

    # ── YASMIN execute ────────────────────────────────────────────────────────

    def execute(self, blackboard: Blackboard) -> str:
        self.node.get_logger().info("[PATROL] State started.")

        wp = WAYPOINTS[self.waypoint_index]
        self._result_future = None
        self._status = None
        self.new_obstacle_detected = False

        if not self._go_to_pose(wp["x"], wp["y"], wp["yaw"]):
            # Goal rejected → stay in patrol and retry next cycle
            return "patrol"

        # Wait for navigation to finish; break early on obstacle alert
        while not self._is_nav_complete():
            rclpy.spin_once(self.node, timeout_sec=0.1)
            if self.new_obstacle_detected:
                self._goal_handle.cancel_goal_async()
                self.node.get_logger().warn(
                    "[PATROL] Navigation interrupted — obstacle detected!"
                )
                return "detected"

        # Advance to next waypoint (circular)
        self.waypoint_index = (self.waypoint_index + 1) % len(WAYPOINTS)
        blackboard["last_waypoint"] = self.waypoint_index

        if self._status == GoalStatus.STATUS_SUCCEEDED:
            self.node.get_logger().info("[PATROL] Waypoint reached.")
            return "patrol"

        # Nav2 reported a failure (aborted, cancelled externally, etc.)
        return "patrol"
