#!/usr/bin/env python3
# -*- coding: UTF-8 -*-

"""
File: state_main/mapping.py

MappingState — stops the robot and performs a 360° rotation so that
obstacle_mapper_node (listening continuously on /scan) can capture the
full obstacle geometry before the robot resumes patrol.

Outcome:
  "mapped" → scan complete, return to PATROL
"""

import math

import rclpy
from rclpy.node import Node
from rclpy.duration import Duration
from geometry_msgs.msg import Twist

from yasmin import State
from yasmin import Blackboard

# Angular velocity for the 360° rotation [rad/s]
# 2π / 0.3 ≈ 21 s for a full turn — adjust if needed.
ANGULAR_VEL = 0.3  # rad/s


class MappingState(State):
    """Stops the robot and rotates 360° to scan a newly detected obstacle."""

    def __init__(self, node: Node):
        super().__init__(outcomes=["mapped"])

        self.node = node
        self.vel_pub = self.node.create_publisher(
            msg_type=Twist,
            topic="cmd_vel",
            qos_profile=10,
        )

    def execute(self, blackboard: Blackboard) -> str:
        self.node.get_logger().info(
            "[MAPPING] State started — scanning surroundings..."
        )

        # 1. Stop the robot
        self.vel_pub.publish(Twist())
        self.node.get_clock().sleep_for(Duration(seconds=1))

        # 2. Rotate 360° so the LiDAR captures the full obstacle.
        #    obstacle_mapper_node listens to /scan continuously,
        #    so simply rotating is enough to get a complete scan.
        twist = Twist()
        twist.angular.z = ANGULAR_VEL
        rotation_time = int(2 * math.pi / ANGULAR_VEL)  # seconds

        self.node.get_logger().info(
            f"[MAPPING] Rotating 360° ({rotation_time} s)..."
        )

        for _ in range(rotation_time):
            self.vel_pub.publish(twist)
            self.node.get_clock().sleep_for(Duration(seconds=1))
            rclpy.spin_once(self.node, timeout_sec=0.1)

        # 3. Stop after full rotation
        self.vel_pub.publish(Twist())
        self.node.get_clock().sleep_for(Duration(seconds=1))

        self.node.get_logger().info(
            "[MAPPING] 360° scan complete — obstacle mapped."
        )
        return "mapped"
