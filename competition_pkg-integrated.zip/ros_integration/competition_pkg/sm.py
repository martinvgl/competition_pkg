#!/usr/bin/env python3
# -*- coding: UTF-8 -*-

"""
File: sm.py

Autonomous Rescue / Evacuation Robot — integrated state machine
States:
  PATROL     → waypoint navigation, monitors LiDAR for new obstacles
  MAPPING    → stops and rotates 360° to scan a detected obstacle
  FOLLOW     → camera-based person / green-exit / red-obstacle detection
  NAVIGATION → Nav2 navigation to the evacuation point

Transitions:
  PATROL     --detected-->      MAPPING
  MAPPING    --mapped-->        PATROL
  PATROL     --person_found-->  FOLLOW
  FOLLOW     --person_found-->  NAVIGATION
  FOLLOW     --search_complete--> PATROL
  NAVIGATION --succeed-->       EXIT
  NAVIGATION --failed-->        PATROL
"""

import rclpy
from rclpy.node import Node
from rclpy.duration import Duration
from geometry_msgs.msg import Twist

from yasmin import StateMachine
from yasmin_viewer import YasminViewerPub

from .state_main import follow
from .state_main import navigation
from .state_main import patrol
from .state_main import mapping


class StateMachineNode(Node):
    """Main State Machine Node — runs the 4-state rescue robot SM."""

    def __init__(self):
        super().__init__("sm_main")

        self.get_logger().info(
            "\033[42m\033[30m\033[1m"
            "==== AUTONOMOUS RESCUE ROBOT START ===="
            "\033[0m"
        )

        input("Press ENTER to start...\n")
        self.get_logger().info("Mission Started!")

        self.vel_pub = self.create_publisher(Twist, "cmd_vel", 10)

        sm = StateMachine(outcomes=["EXIT"])

        sm.add_state(
            name="PATROL",
            state=patrol.PatrolState(node=self),
            transitions={
                "detected":     "MAPPING",
                "person_found": "FOLLOW",
                "patrol":       "PATROL",
            },
        )

        sm.add_state(
            name="MAPPING",
            state=mapping.MappingState(node=self),
            transitions={
                "mapped": "PATROL",
            },
        )

        sm.add_state(
            name="FOLLOW",
            state=follow.FollowState(node=self),
            transitions={
                "person_found":    "NAVIGATION",
                "search_complete": "PATROL",
            },
        )

        sm.add_state(
            name="NAVIGATION",
            state=navigation.NavigationState(node=self),
            transitions={
                "succeed": "EXIT",
                "failed":  "PATROL",
            },
        )

        YasminViewerPub(fsm_name="RESCUE_ROBOT_SM", fsm=sm)

        self.get_logger().info("Executing State Machine...")
        outcome = sm()
        self.get_logger().info(
            f"State Machine finished with outcome: {outcome}"
        )


def shutdown(node: Node):
    """Stop the robot cleanly on exit."""
    node.get_logger().info("Stopping Robot...")
    pub = node.create_publisher(Twist, "cmd_vel", 10)
    pub.publish(Twist())
    node.get_clock().sleep_for(Duration(seconds=1))
    node.destroy_publisher(pub)
    node.get_logger().info("Robot stopped safely.")


def main(args=None):
    rclpy.init(args=args)
    node = None
    try:
        node = StateMachineNode()
    except KeyboardInterrupt:
        print("\nKeyboard Interrupt Detected!")
    finally:
        if node is not None:
            shutdown(node)
            node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()
